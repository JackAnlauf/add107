import UIKit

//Operator race
//The goal is to go the furthest in 4 units of time, or the finish line is 100 units away

let finish = 100

var playerPos = 0
var oppPos = 0

var playerSpeed = 10  // 10 units of distance per unit of time
var oppSpeed = 10

// Start
//—------------------------------------------------------------

playerSpeed += 2
oppSpeed += 1
// 1 unit of time passed..

playerPos += playerSpeed * 1
oppPos += playerSpeed * 1
//—-------------------------------------------------------------

playerSpeed = playerSpeed * 1
oppSpeed = playerSpeed * 2
// 1 unit of time passed..

playerPos += playerSpeed * 1
oppPos += playerSpeed * 1
//—----------------------------------------------------------------

playerSpeed = playerSpeed / 5
oppSpeed = oppSpeed / 3
// 1 unit of time passed

playerPos += playerSpeed * 1
oppPos += playerSpeed * 1

//—----------------------------------------------------------------

playerSpeed = playerSpeed - 1
oppSpeed = oppSpeed - 2
// 1 unit of time passed

playerPos += playerSpeed * 2
oppPos += playerSpeed * 1

//—----------------------------------------------------------------


// Finish

if playerPos > oppPos {
    print("player went further than opponent")
    var togo = finish - playerPos
    print("player had ", togo, "units togo.")
    playerPos
    finish
    var total = (Double(28) / 100)  * 100
    print("player finished ", Int(total), " % of the race!")
}
else if !(playerPos != oppPos) {
    print("It's a tie")
}
else {
    print("opponent went further than opponent")
    var togo = finish - oppPos
    print("opponent had “, togo, “units togo.")
    var total = (oppPos / finish)  * 100
    print("opponent finished “, total, “ % of the race!" )
}
    








