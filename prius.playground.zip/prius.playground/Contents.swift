import UIKit


/*      Example models, colors, packages and accessories
Models
    Prius: The base model with essential features.
    Prius Eco: Focuses on fuel efficiency with lightweight components.
    Prius LE: Adds more convenience and tech features.
    Prius XLE: Offers advanced safety and luxury features.
    Prius Limited: The top-tier model with premium options and tech.

Colors
    Toyota typically offers a variety of colors for the Prius. Popular options may include:
    Classic Silver Metallic
    Midnight Black Metallic
    Blizzard Pearl (white)
    Blue Magnetism
    Supersonic Red
    Electric Storm Blue
    Sea Glass Pearl
 
Packages
    Various packages may be available depending on the model year and trim. Common options include:

    Technology Package: Enhanced tech features like advanced navigation and premium audio systems.

    Advanced Safety Package: Additional safety features such as adaptive cruise control and lane departure alert.
    Premium Package: Includes leather upholstery, heated seats, and other luxury features.

Accessories

    All-Weather Floor Mats: Protects the interior from dirt and spills.
    Cargo Mat: Provides protection for the trunk area.
    Roof Railing: For additional cargo options.
    Bike Rack: Easily transport bikes.
    Mud Guards: Protect the body from mud and debris.
    Window Tinting: For privacy and sun protection.

*/


/*
Create the recipe and ingredients to define a playground that allows you to select the 
 model,
 color,
 packages,
 accessories.


 
 
 RECIPE
 
 Ingredients
    
    swift class syntax
    functions
    attributes of the car(s)
 
 
 Instructions
    1. create class
        1. Create the properties inside the class
        2. create the initializer function to take in model, color, packages, accesseries. And use the "self."  sytnax to assign these to properties for the class
        3. create "getter" functions for each attribute that return the attrtibute and print something to the console.
        4. create other functions to be helpful
            (in hindsight, setter/adder/remover functions were added)
 
    2. create a new class object
    3. show how to use the functions in the class
 
*/


class Prius {
    
    let model: String
    var color: String?
    var packages: [String]
    var accessories: [String]
    
    
    /* Init function. Requires the permenant model at initialization. Other properties set/changed later */
    /* I have it this way because there is a customization process using setter/getter function */
    init(model: String) {
        self.model = model
        self.color = nil
        self.packages = []
        self.accessories = []
    }
    
    
    /* Getter functions */
    func getModel() -> String {
        return self.model
    }
    
    func getColor() -> String {
        return self.color!
    }
    
    func getPackages() -> [String] {
        return self.packages
    }
    
    func getAccessories() -> [String] {
        return self.accessories
    }
    
    
    /* Setter functions that add-to/change properties */
    func changeColor(color: String) {
        self.color = color
    }
    
    func addPackages(packages: [String]) {
        for package in packages {
            self.packages.append(package)
        }
    }
    
    func addAccessories(accessories: [String]) {
        for accessory in accessories {
            self.accessories.append(accessory)
        }
    }
    
    
    /* Remover functions at remove properties */
    func removeColor() {
        self.color = nil
    }
    
    func removePackage(package: String) {
        self.packages.removeAll { $0 == package }
    }
    
    func removeAccessory(accessory: String) {
        self.accessories.removeAll { $0 == accessory }
    }
    
    
    
}



//what model of prius would you like?
var myPrius = Prius(model: "Prius ECO")
print("You have selected a ", myPrius.getModel(), ". ")


// What color would you like your prius to start as?
myPrius.changeColor(color: "red")
print("Your prius will come in the color: ", myPrius.getColor(), ". ")


//what packages(s) would you like to add to your prius?
myPrius.addPackages(packages: ["Technology Package"])
print("your prius will have these packages: ", myPrius.getPackages().joined(separator: ", "))

//what accessories would you like to add to your prius?
myPrius.addAccessories(accessories: ["Bike Rack"])

//are you sure you want just ONE accessory?
myPrius.addAccessories(accessories: ["Window Tinting"])
print("your prius will have these accessories: ", myPrius.getAccessories().joined(separator: ", "))

//changed my mind
myPrius.removeAccessory(accessory: "Bike Rack")
print("your prius now has these accessories: ",  myPrius.getAccessories().joined(separator: ", "))


