import UIKit
import Foundation

//gym wardrobe
var wardrobe: [String:[String]] = [
    "Shirts":["blue_T","black_T","grey_T","red_T","white_T"], //5
    "Shorts":["grey_S","black_S_1","black_S_2","blue_S","white_S"], //5
    "Socks":["white_1","white_2","grey_1","black_1","black_2",], //5
    "Shoes":["nike","adidas"] //2

]

let gymDays: [Int:String] = [
    1:"Monday",
    2:"Tuesday",
    3:"Wednesday",
    4:"Thursday",
    5:"Friday"

]

var wardrobePlan = ""

for i in 0...4 { // 5 days
    let options = 4-i //how many options for shirts, shorts, socks
    
    //pick  random shirt
    let shirtIndex = Int.random(in: 0...options)
    let shirt = (wardrobe["Shirts"])!.remove(at: shirtIndex)
    
    //pick a random pair of shorts
    let shortIndex = Int.random(in: 0...options)
    let shorts = (wardrobe["Shorts"])!.remove(at: shortIndex)
    
    //pick a random pair of socks
    let sockIndex = Int.random(in: 0...options)
    let socks = (wardrobe["Socks"])!.remove(at: sockIndex)
    
    let shoeIndex = Int.random(in: 0...1)
    let shoes = wardrobe["Shoes"]!
    let shoe = shoes[shoeIndex]
    
    
    let day = gymDays[i+1]!

    wardrobePlan += "Gym outfit for " + day + " is: " +
                    shirt + ", " +
                    shorts + ", " +
                    socks + ", and the " +
                    shoe + " shoes.\n"
}

print(wardrobePlan)
