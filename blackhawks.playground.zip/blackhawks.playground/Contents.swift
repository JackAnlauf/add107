import UIKit
import Foundation


let roster: [Int: [String]] = [
    22: ["Joey Anderson", "RW", "R", "72", "207", "1998-06-19", "Roseville, Minnesota, USA"],
    89: ["Andreas Athanasiou", "C", "L", "74", "190", "1994-08-06", "Woodbridge, Ontario, CAN"],
    98: ["Connor Bedard", "C", "R", "70", "185", "2005-07-17", "North Vancouver, British Columbia, CAN"],
    59: ["Tyler Bertuzzi", "LW", "L", "74", "200", "1995-02-24", "Sudbury, Ontario, CAN"],
    28: ["Colton Dach", "C", "L", "76", "196", "2003-01-04", "St. Albert, Alberta, CAN"],
    16: ["Jackson Dickinson", "C", "L", "74", "200", "1995-07-04", "Georgetown, Ontario, CAN"],
     8: ["Ryan Donato", "C", "L", "72", "190", "1996-04-09", "Boston, Massachusetts, USA"],
    17: ["Nick Foligno", "LW", "L", "72", "210", "1987-10-31", "Buffalo, New York, USA"],
    70: ["Cole Guttman", "C", "R", "69", "167", "1999-04-06", "Northridge, California, USA"],
    71: ["Taylor Hall", "LW", "L", "73", "210", "1991-11-14", "Calgary, Alberta, CAN"],
    92: ["Gavin Hayes", "LW", "R", "73", "177", "2004-05-14", "Ypsilanti, Michigan, USA"],
    23: ["Philipp Kurashev", "C", "L", "72", "190", "1999-10-12", "Munsingen, CHE"],
    76: ["Nick Lardis", "LW", "L", "71", "165", "2005-07-08", "Oakville, Ontario, CAN"],
    90: ["Paul Ludwinski", "C", "L", "71", "172", "2004-04-23", "Toronto, Ontario, CAN"],
    43: ["Jalen Luypen", "C", "L", "70", "155", "2002-06-28", "Kelowna, British Columbia, CAN"],
    77: ["Patrick Maroon", "LW", "L", "75", "234", "1988-04-23", "St. Louis, Missouri, USA"],
    95: ["Ilya Mikheyev", "RW", "L", "74", "192", "1994-10-10", "Omsk, RUS"],
    68: ["Martin Misiak", "RW", "L", "74", "194", "2004-09-30", "Banská Bystrica, SVK"],
    91: ["Frank Nazar", "C", "R", "69", "175", "2004-01-14", "Detroit, Michigan, USA"],
    73: ["Lukas Reichel", "LW", "L", "72", "170", "2002-05-17", "Nürnberg, DEU"],
    36: ["Ryder Rolston", "RW", "R", "73", "175", "2001-10-31", "Boston, Massachusetts, USA"],
    12: ["Zachary Sanford", "LW", "L", "76", "206", "1994-11-09", "Salem, Massachusetts, USA"],
    67: ["Samuel Savoie", "LW", "L", "70", "189", "2004-03-25", "Dieppe, New Brunswick, CAN"],
    62: ["Brett Seney", "LW", "L", "69", "156", "1996-02-28", "London, Ontario, CAN"],
    84: ["Landon Slaggert", "LW", "L", "72", "180", "2002-06-25", "South Bend, Indiana, USA"],
    15: ["Craig Smith", "C", "R", "73", "203", "1989-09-05", "Madison, Wisconsin, USA"],
    86: ["Teuvo Teravainen", "C", "L", "71", "191", "1994-09-11", "Helsinki, FIN"],
    83: ["Marek Vanacker", "LW", "L", "73", "174", "2006-04-12", "London, Ontario, CAN"],
    42: ["Nolan Allen", "D", "L", "74", "195", "2003-04-28", "Saskatoon, Saskatchewan, CAN"],
    78: ["TJ Brodie", "D", "L", "74", "187", "1990-06-07", "Chatham, Ontario, CAN"],
    46: ["Louis Crevier", "D", "R", "80", "228", "2001-05-04", "Quebec City, Quebec, CAN"],
    38: ["Ethan Del Mastro", "D", "L", "76", "210", "2003-01-15", "Burlington, Ontario, CAN"],
     4: ["Seth Jones", "D", "R", "76", "213", "1994-10-03", "Arlington, Texas, USA"],
    44: ["Wyatt Kaiser", "D", "L", "72", "173", "2002-07-31", "Andover, Minnesota, USA"],
    14: ["Kevin Korchinski", "D", "L", "73", "185", "2004-06-21", "Saskatoon, Saskatchewan, CAN"],
    55: ["Artyom Levshunov", "D", "R", "74", "208", "2005-10-28", "Zhlobin, BLR"],
    25: ["Alec Martinez", "D", "L", "73", "210", "1987-07-26", "Rochester Hills, Michigan, USA"],
     5: ["Connor Murphy", "D", "R", "76", "212", "1993-03-26", "Dublin, Ohio, USA"],
    41: ["Isaak Phillips", "D", "L", "75", "205", "2001-09-28", "Barrie, Ontario, CAN"],
    72: ["Alec Vlasic", "D", "L", "78", "217", "2001-06-05", "Wilmette, Illinois, USA"],
    39: ["Laurent Brossoit", "G", "L", "75", "203", "1993-03-23", "Port Alberni, British Columbia, CAN"],
    33: ["Drew Commesso", "G", "L", "74", "180", "2002-07-19", "Norwell, Massachusetts, USA"],
    34: ["Petr Mrazek", "G", "L", "74", "188", "1992-02-14", "Ostrava, CZE"],
    40: ["Arvid Soderblom", "G", "L", "75", "180", "1999-08-19", "Göteborg, SWE"]
]


//RECIPE

    
    /*      INGREDIENTS
     
     1.     The roster dictionary, key = number: value = [strings]
            index i
            i = 0  player name
            i = 1  position
            i = 2  shooting hand
            i = 3  height in inches
            i = 4  weight in pounds
            i = 5  birthday as "yyyy-mm-dd"
            i = 6  birthplace
     2.     for loops to iterate over the roster
     3.     string components function                https://developer.apple.com/documentation/foundation/nsstring/1413214-components
     4.     swifts sorted() function.
     5.     swift date formatter function
     5.     swift max() function
     6.     Dictionaries to hold names of months, their numeric representation, and their value
     
    
     
     */



    /*      INSTRUCTIONS
     
     
     
            TO SORT BY COUNTRY. 
            initialize a dictionary of the type String:[String]... example ["USA":["Anderson",...]]
            Iterate over the entire roster. use the index of the birthplace and the last component of that birthplace string.
            if the country is unique to the dictionary, add it as a key and its value as a list, with its first entry as the player name from that unique country.
            if not unique, add that player name to the corresponding country.
            
            initialize our final list of sorted players
            iterate through the original dictionary by the country (key), for each country, iterate through the country roster (value), adding each player to
            our final list. The final list should be all sorted by country.
     
     
    
     
            TO SORT BY AGE.
            https://www.advancedswift.com/date-formatter-cheatsheet-formulas-swift/#convert-string-to-date
            https://developer.apple.com/documentation/swift/array/sorted(by:)
            https://stackoverflow.com/questions/24130026/how-to-sort-an-array-of-custom-objects-by-property-value
     
            first create a formatter with the matching format to the format of the string in the age entry in the roster values. it is critical the the formats in the roster are ALL consistent.
            then use the sorted function to create a comparator for the age value of each player, using the formatter to convert the strings into comparable date objects.
            then use a simple forloop to loop over the new sorted dictionary, adding the name of the player to the list.
     
     
            TO CALCULATE THE AVERAGE AGE OF PLAYERS.
     
            keep a total age sum in a variable
            keep a player count in a varaible
            keep the current date in a constant
            loop through the roster
            convert, using the previous formatter, the age of the current player into a date object.
            subtract player date  from current date, add the difference to the running total, incriment the sum total in the form of days.
            https://stackoverflow.com/questions/40075850/swift-3-find-number-of-calendar-days-between-two-dates
            
            after completing the for loop, convert the days sum into years and days through modulo and regular division
     
            
            TO GET AVERAGE HEIGHT.
            
            the roster has each player listed in inches.
            loop through the roster, increasing a running sum of the total players and cummulative height, then find the average
            
     
     
            TO GET MOST COMMON MONTH.
     
            keep a dictionary for each month, it's value is the count
            loop through the roster, using string components like before, finding different months and adding to the months dictionary
            use the dictionary to find the most common month
     
     

     */





/* SORTING BY COUNTRY */

var countryRosters: [String:[String]] = [:]

for (key, value) in roster {
    var playerLocation = value[6]
    var playerName: String = value[0]
    let playerCountryComponents = playerLocation.components(separatedBy: ", ")
    let playerCountry: String = (playerCountryComponents.last)!
    
    
    if countryRosters[playerCountry] == nil {
        countryRosters[playerCountry] = []
    }
    countryRosters[playerCountry]?.append(playerName)
    
}


var countryRostersList: [String] = []
var countryRostersOrder: [String] = []
var countryRostersString: String = ""


for (key, value) in countryRosters{
    countryRostersOrder.append(key)
    countryRostersString += key + "\n"
    
    for player in value {
        countryRostersList.append(player)
        countryRostersString += player + "\n"
    }
    countryRostersString += "\n"

    
}
print(countryRostersString)
print(countryRostersList)







/*    SORTED BY AGE           */


let formatter = DateFormatter()
formatter.dateFormat = "yyyy-MM-dd"

let sortedRoster = roster.sorted { (player0,player1) -> Bool in
    let date0: Date = formatter.date(from: (player0.value[5]))!
    let date1: Date = formatter.date(from: (player1.value[5]))!
    return date0 < date1
}

var ageRoster: [String] = []
var ageString: String = ""
for (key,value) in sortedRoster {
    ageRoster.append(value[0])
    ageString += value[0] + ": " + value[5] + "\n"
}




/*      AVERAGE AGE      */
let today = formatter.date(from: "2024-09-27")!
var playerCount = 0
var daySum = 0



for (key,value) in roster {
    let playerDate = formatter.date(from: value[5])!
    let difference = Calendar.current.dateComponents([.day], from: playerDate, to: today).day!
    
    daySum += difference
    playerCount += 1
    
        
}

let average = daySum / playerCount
let years = average / 365
let days = average % 365




/*          AVERAGE HEIGHT          */


var heightSum = 0

for (key,value) in roster {
    heightSum += Int(value[3])!
    
}

let averageHeight = heightSum / playerCount
let averageFeet = averageHeight / 12
let averageInches = averageHeight % 12

print(averageFeet, "Foot, ", averageInches, " Inches")



/*         MOST COMMON MONTH           */



var monthNumbers: [String: Int] = [
    "01": 0,
    "02": 0,
    "03": 0,
    "04": 0,
    "05": 0,
    "06": 0,
    "07": 0,
    "08": 0,
    "09": 0,
    "10": 0,
    "11": 0,
    "12": 0
]


let monthNames = [
    "01": "January",
    "02": "February",
    "03": "March",
    "04": "April",
    "05": "May",
    "06": "June",
    "07": "July",
    "08": "August",
    "09": "September",
    "10": "October",
    "11": "November",
    "12": "December"
]

for (key,value) in roster {
    var birthday = value[5]
    let monthNum = birthday.components(separatedBy:  "-")
    let month = (monthNum[1])
    print(month,type(of: month))
    var old: Int = monthNumbers[month]!
    monthNumbers[month] = old + 1

}


var bestMonth = "01"
var bestCount = 0
var monthCountString = ""
var winners = ""

for (month,count) in monthNumbers {
    monthCountString += monthNames[month]! + ": " + String(count) + "\n"
    if count > bestCount {
        bestCount = count
        bestMonth = month
    }
}


for (month,count) in monthNumbers {
    if count == bestCount {
        winners += monthNames[month]! + "\n"
    }
        
}

print(monthCountString)
print("the most common birthmonth is \n", winners, "\n with ", bestCount, " occurances")








