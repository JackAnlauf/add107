import UIKit


//The top section defines all your input variables

var x = 8
var y = 2

//The middle section defines all the operations
//Add/Subtract/Multiply/Divide/Percentages

var addition = x + y
var subtraction = x - y
var multiplication = x * y
var division = x / y
var percentage = (x / y) * 100

//The bottom section prints all the results to the screen

print(x, " added to " , y , " = ", addition)
print(y, " subtracted from " , x , " = ", subtraction)
print(x, " multiplied by " , y , " = ", multiplication)
print(x, " divided by " , y , " = ", division)
print(x, " is (", percentage , ")% of ", y)






