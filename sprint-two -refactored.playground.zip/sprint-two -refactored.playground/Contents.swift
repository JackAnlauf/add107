import UIKit


/*  CLASS STRUCTURE FOR EXERCISE  */
class Exercise {
    
    /* CLASS PROPERTIES */
    let name: String
    
    var records: Records
    
    var goals: Goals
    
    
    /* INIT FUNCTION */
    init(name: String) {
        self.name = name
        self.records = Records()
        self.goals = Goals()
        
        
    }

    /*  CLASS METHODS  */
    
    func getRepRecords() -> [Int:[Record]]  {
        return self.records.repRecords
    }
    
    func getWeightRecords() ->  [Int:[Record]]  {
        return self.records.weightRecords
    }
    
    // print a summary analysis
    func analyzeAbsolutePR() -> String {
        
        let (personalRecord,record) = self.records.absolutePR()
    
        let string =    "Exercise: " +
                        self.name +
                        ". Personal Record: " +
                        String(personalRecord) +
                        " for " +
                        String(record.value) +
                        " rep(s). During session " +
                        String(record.session) +
                        "on this date: " +
                        record.date
                        "."
        return string
    }
    
    func progression(weight: Int) {
        let (weightPR,recordPR) = self.records.absolutePR()
        let goal = self.goals.getBigGoal(weight: weight)
        
        print("goal weight: ", goal.weight)
        print("goal reps: ", goal.reps)
        print("goal date", goal.date)
        
        print("pr weight: ", weightPR)
        print("pr reps: ", recordPR.value)

        let weightPercentage = Double(weightPR) * 100 / Double(goal.weight)
        let repPercentage = Double(recordPR.value) * 100 / Double(goal.reps)
        
        if weightPercentage > 100 {
            print("You achieved your goal of ", goal.weight, " pounds for ", self.name)
            if repPercentage > 100 {
                print("And you achieved your goal of ", goal.reps, " reps for that weight.")
            }
            else {
                print("However you are ", goal.reps - recordPR.value, "reps away from ", goal.reps, ". ", Int(floor(repPercentage)), "% of the way.")
            }
        }else {
            print("You are ", Int(floor(weightPercentage)), "% of the way to your weight goal of ", goal.weight, " pounds.")
            print("Your goal is set for ", goal.date)
        }
        
        
        
        
        
        
    }
    // progression for a single rep range, usually 1 rep
    func progression(reps: Int) {
        var repProgression = "\nProgression for " + String(reps) + " rep range\n"

        let records = self.records.repRecords[reps]!.sorted{ $0.session < $1.session}
        for record in records {
            let sessionWeight = (("Session: ") + String(record.session) + (" Weight: ") + (String(record.value)) + "\n")
            repProgression += sessionWeight
        }
        
        print(repProgression)
        
        
    }
    
    // progression for a rep range lo, hi of the range inclusive
//    func progression(reps: (Int,Int)) {
//
//    }


}


// Struct and Class for records

struct Record {
    let value: Int
    let session: Double
    let date: String
    
}


class Records {
    var weightRecords: [Int:[Record]]
    var repRecords: [Int:[Record]]
    
    init() {
        weightRecords = [:]
        repRecords = [:]
    }
    
    //add a record
    func addRecord(weight: Int, reps: Int, session: Double, date: String) {
        if !self.repRecords.keys.contains(reps){
            self.repRecords[reps] = [Record(value: weight, session: session, date: date)]
        }
        else {
            self.repRecords[reps]?.append(Record(value: weight, session: session, date: date))
        }
        
        if !self.repRecords.keys.contains(weight){
            self.weightRecords[weight] = [Record(value: reps, session: session, date: date)]
        }
        else {
            self.weightRecords[weight]?.append(Record(value: reps, session: session, date: date))
        }
    }
    
    
    // find the MiniPR for a weight
    func repMiniPR(weight: Int) -> Int {
        var repPR = 0
        if let records = self.weightRecords[weight] {
            for repRecord in records {
                if repRecord.value > repPR {
                    repPR = repRecord.value
                }
            }
        }
        return repPR
    }
    
    // find the MiniPR for a rep range
    func weightMiniPR(reps: Int) -> Int {
        var weightPR = 0
        if let weightRecords = self.repRecords[reps]{
            for weightRecord in weightRecords {
                if weightRecord.value > weightPR {
                    weightPR = weightRecord.value
                }
                
            }
        }
        return weightPR
    }
    
    // returns the absolute PR of the exercise, as well as it's reps and date/session
    // var weight_records: [Int:[Record]]
    func absolutePR() -> (Int,Record) {
        if let personalRecord = self.weightRecords.max(by: { $0.key < $1.key }) { //highest weight
            if let bestRecord = personalRecord.value.max(by: { $0.value < $1.value }) { //highest rep for that weight
                return (personalRecord.key,bestRecord)  //return the weight with the full record
            }
            return (0,Record(value: 0, session: 0, date: "0"))
        }
        return (0,Record(value: 0, session: 0, date: "0"))
    }
    
    
}


// Struct and Class for Goals (

struct Goal {
    let weight: Int
    let reps: Int
    let date: String
}


class Goals {
    var bigGoals: [Goal]
    var miniGoals: [Goal]
    
    init() {
        self.bigGoals = []
        self.miniGoals = []
    }
    
    
    func addBigGoal(weight: Int, reps: Int, date: String) {
        self.bigGoals.append(Goal(weight: weight, reps: reps, date: date))
        
    }
    
    func addMiniGoal(weight: Int, reps: Int, date: String) {
        self.miniGoals.append(Goal(weight: weight, reps: reps, date: date))
        
    }
    
    func getBigGoal(weight: Int) -> Goal {
        var goals = self.bigGoals.filter({$0.weight == weight})
        if goals.isEmpty {
            return Goal(weight: 0, reps: 0, date: "0")
        }
        return goals.max(by: { $0.reps < $1.reps })!
        
        
    }
    
    
}













var myBenchpress = Exercise(name: "Benchpress")
myBenchpress.goals.addBigGoal(weight: 225, reps: 5, date: "11-31-24")

myBenchpress.records.addRecord(weight: 205, reps: 2, session: 1.1, date: "11-1-24")
myBenchpress.records.addRecord(weight: 210, reps: 2, session: 1.2, date: "11-3-24")
myBenchpress.records.addRecord(weight: 215, reps: 2, session: 1.3, date: "11-5-24")

print("\n")
myBenchpress.progression(weight: 225)
myBenchpress.progression(reps: 2)
